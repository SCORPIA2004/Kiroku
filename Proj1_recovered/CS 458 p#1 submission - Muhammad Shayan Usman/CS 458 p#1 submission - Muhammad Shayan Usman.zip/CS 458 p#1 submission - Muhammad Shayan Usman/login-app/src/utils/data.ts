// utils/data.ts
// email, passwords, name, city, dob
export const credentials = [
  { email: "test@example.com", password: "password123" },
  { email: "user1@example.com", password: "securepass1" },
  { email: "admin@example.com", password: "admin123" },
  { email: "doctor@example.com", password: "medic987" },
  { email: "staff@example.com", password: "staffpass" },
];
